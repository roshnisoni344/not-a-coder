package com.cognizant.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Sector {
	@Id
	private int sectorId;
	private String sectorName;
	private String briefWriteUp;
	
	public int getSectorId() {
		return sectorId;
	}
	public void setSectorId(int sectorId) {
		this.sectorId = sectorId;
	}
	public String getSectorName() {
		return sectorName;
	}
	public void setSectorName(String sectorName) {
		this.sectorName = sectorName;
	}
	public String getBriefWriteUp() {
		return briefWriteUp;
	}
	public void setBriefWriteUp(String briefWriteUp) {
		this.briefWriteUp = briefWriteUp;
	}
	@Override
	public String toString() {
		return "Sector [sectorId=" + sectorId + ", sectorName=" + sectorName + ", briefWriteUp=" + briefWriteUp + "]";
	}

}
