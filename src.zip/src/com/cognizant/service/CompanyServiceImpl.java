package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.CompanyDao;
import com.cognizant.dao.UserDao;
import com.cognizant.entity.Company;
import com.cognizant.entity.User;

@Service
public class CompanyServiceImpl implements CompanyService {

	@Autowired
	private CompanyDao companyDao;

	public Company save(Company company) {
		return companyDao.save(company);
	}

}