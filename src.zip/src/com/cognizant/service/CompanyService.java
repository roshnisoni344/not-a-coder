package com.cognizant.service;

import com.cognizant.entity.Company;

public interface CompanyService {

	Company save(Company company);

}
