package com.cognizant.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Company;
import com.cognizant.entity.User;

@Repository
public interface CompanyDao extends CrudRepository<User, Long> {

	Company save(Company company);

	
}
