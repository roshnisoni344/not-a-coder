package com.cognizant.dao;

import java.io.Serializable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.cognizant.entity.StockExchange;

@Repository
public interface StockExchangeDao extends CrudRepository<StockExchange, Serializable> 
{
	 StockExchange save(StockExchange stockexchange);
}
