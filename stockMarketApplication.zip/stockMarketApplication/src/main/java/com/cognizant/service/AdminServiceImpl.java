package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.dao.AdminDao;
import com.cognizant.dao.CompanyDao;
import com.cognizant.dao.StockExchangeDao;
import com.cognizant.dao.UserDao;
import com.cognizant.entity.Company;
import com.cognizant.entity.StockExchange;
import com.cognizant.entity.User;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminDao adminDao;

	@Autowired
	private CompanyDao companyDao;

	@Autowired
	private StockExchangeDao stockExchangeDao;

	@Autowired
	private UserDao userdao;

	@Override
	public Company save(Company company) {
		return companyDao.save(company);
	}

	@Override
	public void deleteBycompanyId(long companyId) {
		companyDao.deleteById(companyId);
	}

	@Override
	public StockExchange save(StockExchange stockexchange) {
		return stockExchangeDao.save(stockexchange);
	}

	@Override
	public Company findByCompanyId(long companyId) {
		return companyDao.findByCompanyId(companyId);
	}

	@Override
	public User findById(long id) {
		return userdao.findById(id);
	}

}
