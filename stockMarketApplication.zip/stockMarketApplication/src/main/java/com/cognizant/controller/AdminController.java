package com.cognizant.controller;
import javax.servlet.ServletException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cognizant.entity.Company;
import com.cognizant.entity.StockExchange;
import com.cognizant.entity.User;
import com.cognizant.service.AdminService;
import com.cognizant.service.UserService;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@CrossOrigin(origins = "http://localhost", maxAge = 3600)
@RestController
@RequestMapping("/Admin")
public class AdminController
{

	@Autowired
	UserService userService;

	@Autowired
	AdminService adminService;

	@RequestMapping(value = "/Authorization", method = RequestMethod.POST)

 public String login(@RequestBody User login) throws ServletException {

 String jwtToken = "";

 if (login.getUsername() == null || login.getPassword() == null) {

  throw new ServletException("Please fill in username and password");

 }

 String username = login.getUsername();
 String password = login.getPassword();

 User user = userService.findUser(username, password);
 String usertype=user.getUsertype();
 if (user == null)
 {
  throw new ServletException("Username not found");
 }



 String pwd = user.getPassword();

 if (!password.equals(pwd)) {

  throw new ServletException("Invalid login. Please check your username and password.");

 }

 if(usertype.equalsIgnoreCase("admin"))

 {

 jwtToken = Jwts.builder().setSubject(username).claim("roles", "user")

  .signWith(SignatureAlgorithm.HS256, "secretkey").compact();

 }

 else

 {

  throw new ServletException("No an Admin");

 }

 return jwtToken;



 }



 @RequestMapping(value = "/add/company", method = RequestMethod.POST)

 public Company addCompany(@RequestBody Company company) {

 return adminService.save(company);

 }



 @RequestMapping(value = "/update/company/details", method = RequestMethod.POST)

 public Company updateCompanyDetails(@RequestBody Company company) {

 return adminService.save(company);

 }



 @RequestMapping(value = "/edit/company/database/delete", method = RequestMethod.POST)

 public String deleteCompany(@RequestParam long companyId) {

 adminService.deleteBycompanyId(companyId);

 return "Company Deleted";

 }



 @RequestMapping(value = "/add/stockexchange", method = RequestMethod.POST)

 public StockExchange addstockexchange(@RequestBody StockExchange stockexchange) {

 return adminService.save(stockexchange);

 }



 @RequestMapping(value = "/update/stockexchang/details", method = RequestMethod.POST)

 public StockExchange updatestockexchange(@RequestBody StockExchange stockexchange) {

 return adminService.save(stockexchange);

 }



 @RequestMapping(value = "/company/database/search", method = RequestMethod.POST)

 public Company searchCompany(@RequestBody Company company) {

 long companyId=company.getCompanyId();

 return adminService.findByCompanyId(companyId);

 }
 @RequestMapping(value = "/search", method = RequestMethod.POST)

 public User searchUser(@RequestParam long id) {


 return adminService.findById(id);

 }

 @RequestMapping(value = "/block/user", method = RequestMethod.POST)
 @Transactional
 public String blockUser(@RequestParam long id) {
 User user=new User();
 user=userService.findById(id);
 if(user.getIsIsblock()==true)
 {
	 return "User is already blocked";
 }
 else
 {
	 user.setIsblock(true);
	 return "User is now blocked";
 }
 }

 @RequestMapping(value = "/unblock/user", method = RequestMethod.POST)
 @Transactional
 public String unblockUser(@RequestParam long id) {
 User user=new User();
 user=userService.findById(id);
 if(user.getIsIsblock()==true)
 {
	 user.setIsblock(false);
	 return "User is now unblocked";
 }
 else
 {
	 return "User is already unblocked";
 }
 }
 
 @RequestMapping(value = "/block/company", method = RequestMethod.POST)
 @Transactional
 public String blockCompany(@RequestParam long companyId) {
 Company company=new Company();
 company=adminService.findByCompanyId(companyId);
 if(company.getisCompanyBlock()==true)
 {
	 return "Company is already blocked";
 }
 else
 {
	 company.setCompanyBlock(true);
	 return "Company is now blocked";
 }
 }

 @RequestMapping(value = "/unblock/company", method = RequestMethod.POST)
 @Transactional
 public String unblockCompany(@RequestParam long companyId) {
 Company company=new Company();
 company=adminService.findByCompanyId(companyId);
 if(company.getisCompanyBlock()==true)
 {
	company.setCompanyBlock(false);
	return "Company is now unblocked";
 }
 else
 {
	 return "Company is already unblocked";
 }
 }
 
}



